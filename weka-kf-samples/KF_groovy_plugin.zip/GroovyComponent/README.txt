------------------------------------------------
          GroovyComponent Plugin for 
            the WEKA KnowledgeFlow
------------------------------------------------

INTRODUCTION

This plugin component allows the KnowledgeFlow to execute Groovy
(http://groovy.codehaus.org/) scripts. The component has a graphical
editor that can generate a "template" Groovy class that implements key
KnowledgeFlow interfaces and provides no-op methods that can be filled
in as necessary. Developing/prototyping for the KnowledgeFlow with
Groovy is much faster than coding a standard plugin as Groovy's
dynamic nature does not require the KnowledgeFlow to be restarted
after each change to the code.

REQUIREMENTS

Until the 3.7.0 development version of WEKA is released, this plugin
requires a nightly snapshot of the development version of
WEKA. Snapshots can be downloaded from:

http://www.cs.waikato.ac.nz/ml/weka/snapshots/

INSTALLATION

Create a .knowledgeFlow/plugins directory in your HOME directory
(if one does not already exist). Create a "groovy" subdirectory
of .knowledgeFlow/plugins and copy the contents of the "deploy"
directory into it. After restarting the KnowledgeFlow there should
be a "Plugins" tab available containing the GroovyComponent.

EXAMPLE SCRIPTS

The "scripts" directory contains two example Groovy scripts that you
can load into the GroovyComponent. Configure the GroovyComponent by
either double clicking on it's image on the Layout, or by
right-clicking and selecting "Configure..." from the popup menu. This
will open the script editor window. From here you can create new
scripts, edit scripts or load scripts.

The DirectoryLoader Groovy script is an example that loads all the
ARFF files in a user supplied directory. If this is connected
to a CrossValidationFoldMaker and Classifier then make
sure that the "Block on last fold" option of the Classifier component
is enabled.

The LearningCurve Groovy script is an example that takes a trainingSet
connection and generates a learning curve for a user specified
classifier.  A certain percentage of the data is held out for
generating accuracy scores and the remainder is used to train the
classifier with increasing amounts of data.

More information along with screenshots that show how to connect up
example flows that use these scripts can be found at:

http://wiki.pentaho.com/display/DATAMINING/Groovy+Scripting+in+the+KnowledgeFlow

